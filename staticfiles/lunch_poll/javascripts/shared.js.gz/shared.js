const Shared = {};

Shared.hello = function() {
};

window.onload = function() {
  Shared.hello();
};
